<?php if($query_results->max_num_pages > 1) { ?>
	<div class="edgtf-pl-loading">
        <div class="edgtf-pl-loading-text">
            <?php echo esc_html__('Loading...', 'galatia'); ?>
        </div>
	</div>
<?php }