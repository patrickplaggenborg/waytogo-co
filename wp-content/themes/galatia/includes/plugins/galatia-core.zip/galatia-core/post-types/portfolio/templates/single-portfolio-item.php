<?php

get_header();

galatia_edge_get_title();

do_action('galatia_edge_action_before_main_content');

galatia_core_get_single_portfolio();

get_footer();