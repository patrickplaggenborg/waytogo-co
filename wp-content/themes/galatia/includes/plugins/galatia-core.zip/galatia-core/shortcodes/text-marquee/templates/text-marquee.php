<div class="edgtf-text-marquee <?php echo esc_attr( $holder_classes ); ?>" <?php echo galatia_edge_inline_style( $text_styles ); ?> <?php echo galatia_edge_get_inline_attrs( $text_data ); ?>>
	<span class="edgtf-marquee-element edgtf-original-text"><?php echo esc_html( $text ) ?></span>
	<span class="edgtf-marquee-element edgtf-aux-text"><?php echo esc_html( $text ) ?></span>
</div>  