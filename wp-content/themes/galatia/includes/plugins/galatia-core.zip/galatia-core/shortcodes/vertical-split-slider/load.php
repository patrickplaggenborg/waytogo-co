<?php

include_once GALATIA_CORE_SHORTCODES_PATH . '/vertical-split-slider/functions.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/vertical-split-slider/vertical-split-slider.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/vertical-split-slider/vertical-split-slider-left-panel.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/vertical-split-slider/vertical-split-slider-right-panel.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/vertical-split-slider/vertical-split-slider-content-item.php';