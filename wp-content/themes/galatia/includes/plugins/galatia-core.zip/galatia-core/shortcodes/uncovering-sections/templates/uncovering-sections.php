<div class="edgtf-uncovering-sections">
	<ul class="edgtf-us-wrapper curtains" data-image-holder-name=".edgtf-uss-image-holder" data-fade-element-name=".edgtf-fss-shadow">
		<?php echo do_shortcode($content); ?>
	</ul>
    <div class="edgtf-fss-shadow"></div>
</div>