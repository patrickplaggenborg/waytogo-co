<?php

include_once GALATIA_CORE_SHORTCODES_PATH . '/interactive-link-showcase/functions.php';
include_once GALATIA_CORE_SHORTCODES_PATH . '/interactive-link-showcase/interactive-link-showcase.php';